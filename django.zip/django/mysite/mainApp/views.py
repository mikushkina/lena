from django.shortcuts import render

def index(request):
    return render(request,'mainApp/homePage.html')

def contact(request):
    return render(request,'mainApp/basic.html', {'values': ['Phone: +7-996-949-32-31','VK: https://vk.com/lena_foxberry']})
